#!/usr/bin/env python3
"""Локальная сводка CSV: группа;выполнено;задано. Только стандартная библиотека."""
import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path


def summarize(source):
    groups = defaultdict(lambda: [0, 0, 0, 0])  # строк, без результата, выполнено, задано
    with source.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f, delimiter=';')
        required = {'группа', 'выполнено', 'задано'}
        if not reader.fieldnames or not required.issubset(reader.fieldnames) or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError('Нужны уникальные заголовки: группа;выполнено;задано')
        for row in reader:
            number = reader.line_num
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f'Строка {number}: неверное число полей')
            group = row['группа'].strip()
            if not group:
                raise ValueError(f'Строка {number}: не указана группа')
            try:
                assigned = int(row['задано'].strip())
                raw = row['выполнено'].strip()
                completed = int(raw) if raw else None
            except ValueError:
                raise ValueError(f'Строка {number}: ожидаются целые числа') from None
            if assigned <= 0 or (completed is not None and not 0 <= completed <= assigned):
                raise ValueError(f'Строка {number}: требуется задано > 0 и 0 ≤ выполнено ≤ задано')
            item = groups[group]
            item[0] += 1
            if completed is None:
                item[1] += 1
            else:
                item[2] += completed
                item[3] += assigned
    if not groups:
        raise ValueError('В файле нет строк с данными')
    return groups


def main():
    parser = argparse.ArgumentParser(description='Локальная сводка по группам из CSV')
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    try:
        if args.input.resolve() == args.output.resolve():
            raise ValueError('Входной и выходной файлы должны различаться')
        groups = summarize(args.input)
        # Не перезаписываем существующие файлы, в том числе через символьные ссылки.
        with args.output.open('x', encoding='utf-8', newline='') as f:
            writer = csv.writer(f, delimiter=';')
            writer.writerow(['группа', 'записей', 'без_результата', 'выполнено', 'задано_с_результатом', 'доля_процент'])
            for group, (count, missing, completed, assigned) in sorted(groups.items()):
                percent = f'{100 * completed / assigned:.1f}'.replace('.', ',') if assigned else ''
                writer.writerow([group, count, missing, completed, assigned, percent])
        print('Готово: сводка сохранена локально.')
    except (OSError, UnicodeError, csv.Error, ValueError) as exc:
        print(f'Ошибка: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
