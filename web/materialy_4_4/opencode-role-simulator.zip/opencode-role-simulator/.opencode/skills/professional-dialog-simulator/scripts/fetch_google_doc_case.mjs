// Внутренний ресурс skill. Node LTS, только встроенные модули и fetch.
import { mkdir, writeFile, rename, rm, lstat } from 'node:fs/promises';
import { resolve, dirname, sep } from 'node:path';
import { createHash } from 'node:crypto';
const LIMIT = 131072;
let output;
async function main() {
  const [source, target = 'cases/current_case.md', ...extra] = process.argv.slice(2);
  if (!source || extra.length) throw new Error('Использование: node fetch_google_doc_case.mjs "GOOGLE_DOC_URL" "cases/current_case.md"');
  const root = resolve('cases');
  const candidate = resolve(target);
  if (!candidate.startsWith(root + sep) || !candidate.endsWith('.md')) throw new Error('Выход должен быть Markdown-файлом внутри cases/ открытого проекта.');
  // Не переходить по символьным ссылкам каталогов, чтобы очистка не затронула иной проект.
  let cursor = dirname(candidate);
  while (cursor !== resolve('.')) {
    try { if ((await lstat(cursor)).isSymbolicLink()) throw new Error('Символьные ссылки в пути cases/ не поддерживаются.'); }
    catch (e) { if (e.code !== 'ENOENT') throw e; }
    cursor = dirname(cursor);
  }
  output = candidate;
  await mkdir(dirname(output), { recursive: true });
  // Удаление прошлого снимка намеренно: ошибка не должна выглядеть успешным старым запуском.
  await Promise.all([output, output + '.meta.json', output + '.tmp'].map(p => rm(p, { force: true })));
  let url;
  try { url = new URL(source); } catch { throw new Error('Неверная ссылка. Нужна https://docs.google.com/document/d/ID/edit'); }
  const match = url.pathname.match(/^\/document\/d\/([A-Za-z0-9_-]{10,})(?:\/(?:edit|view|preview|export))?\/?$/);
  if (url.protocol !== 'https:' || url.hostname !== 'docs.google.com' || url.port || url.username || url.password || !match) throw new Error('Нужна обычная HTTPS-ссылка Google Doc /document/d/ID/edit. Ссылки /d/e/, Drive и сторонние адреса не поддерживаются.');
  if (typeof fetch !== 'function') throw new Error('Нужен поддерживаемый Node.js LTS со встроенным fetch.');
  const canonical = `https://docs.google.com/document/d/${match[1]}/edit`;
  let endpoint = `https://docs.google.com/document/d/${match[1]}/export?format=txt`;
  const signal = AbortSignal.timeout(20000);
  let response;
  for (let hop = 0; hop < 6; hop++) {
    response = await fetch(endpoint, { signal, redirect: 'manual', credentials: 'omit', headers: { Accept: 'text/plain' } });
    if (![301, 302, 303, 307, 308].includes(response.status)) break;
    const location = response.headers.get('location');
    if (!location) throw new Error('Google вернул перенаправление без адреса.');
    const next = new URL(location, endpoint);
    if (next.protocol !== 'https:' || next.port || next.username || next.password || !(next.hostname === 'docs.google.com' || next.hostname.endsWith('.googleusercontent.com'))) throw new Error('Документ требует входа или перенаправляет вне разрешённого сервиса. Проверьте Anyone with the link → Viewer и разрешение скачивания.');
    await response.body?.cancel(); endpoint = next.href;
    if (hop === 5) throw new Error('Слишком много перенаправлений.');
  }
  if (!response.ok) throw new Error(`Google Doc недоступен: HTTP ${response.status}. Проверьте доступ Anyone with the link → Viewer, экспорт и сеть.`);
  const mime = (response.headers.get('content-type') || '').toLowerCase();
  if (!mime.startsWith('text/plain')) throw new Error('Вместо текста получена страница входа/HTML или иной формат. Симуляция не начата.');
  const reader = response.body.getReader(); const chunks = []; let size = 0;
  while (true) {
    const { value, done } = await reader.read(); if (done) break;
    size += value.byteLength;
    if (size > LIMIT) { await reader.cancel(); throw new Error('Кейс больше 128 КиБ. Сократите синтетический документ.'); }
    chunks.push(value);
  }
  const text = Buffer.concat(chunks).toString('utf8').replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').trim();
  if (!text || /<!doctype\s+html|<html\b|<script\b|<form\b/i.test(text)) throw new Error('Пустой документ или HTML вместо кейса.');
  const names = ['Версия', 'Видно студенту', 'Роль персонажа', 'Скрытая легенда', 'Что раскрывать только по вопросам', 'Первая реплика'];
  const lines = text.split('\n'); const headings = new Map();
  for (let i = 0; i < lines.length; i++) {
    const h = lines[i].trim().replace(/^#{1,6}\s+/, '').replace(/:$/, '').trim();
    if (names.includes(h)) {
      if (headings.has(h)) throw new Error('Повторяется обязательный раздел: ' + h);
      headings.set(h, i);
    }
  }
  for (const name of names) {
    const pos = headings.get(name);
    if (pos === undefined) throw new Error('Отсутствует раздел: ' + name);
    const next = [...headings.values()].filter(i => i > pos).sort((a,b) => a-b)[0] ?? lines.length;
    if (!lines.slice(pos+1, next).join('\n').trim()) throw new Error('Пустой раздел: ' + name);
  }
  const version = lines[(headings.get('Версия')) + 1]?.trim();
  if (!version || !/^[A-Za-z0-9._-]{1,40}$/.test(version)) throw new Error('Версия должна стоять сразу под заголовком и содержать только латиницу, цифры, . _ - (до 40 символов).');
  const hash = createHash('sha256').update(text).digest('hex');
  const meta = { source: canonical, fetchedAt: new Date().toISOString(), version, sha256: hash, bytes: size, characters: text.length };
  await writeFile(output + '.tmp', text + '\n', { encoding: 'utf8', mode: 0o600 });
  await rename(output + '.tmp', output);
  await writeFile(output + '.meta.json', JSON.stringify(meta, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  console.log(JSON.stringify({ status: 'ok', file: target, version, characters: text.length, sha256: hash }));
}
try { await main(); }
catch (error) {
  if (output) await Promise.all([output, output + '.meta.json', output + '.tmp'].map(p => rm(p, { force: true }).catch(() => {})));
  const reason = error.name === 'TimeoutError' || error.name === 'AbortError' ? 'Загрузка не завершилась за 20 секунд. Проверьте сеть и доступ.' : (error.message === 'fetch failed' ? 'Сетевая ошибка. Проверьте подключение и доступ к Google Docs.' : error.message);
  console.error('Источник не загружен. Симуляция не начата. ' + reason);
  process.exitCode = 1;
}
