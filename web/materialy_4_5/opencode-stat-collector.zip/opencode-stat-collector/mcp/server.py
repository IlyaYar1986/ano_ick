#!/usr/bin/env python3
"""Учебный MCP-сервер: stdio JSON-RPC, только синтетическая ведомость."""
import csv
import json
import math
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
DATA = ROOT / 'data' / 'group_stats.csv'

def analyze(path):
    with pathlib.Path(path).open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError('Таблица пуста')
    ids, total_grade, total_absences, unexcused, failed, risk = set(), 0.0, 0, 0, 0, []
    for row in rows:
        student = row['student_id'].strip()
        if not student or student in ids:
            raise ValueError('Пустой или повторяющийся student_id')
        ids.add(student)
        grade = float(row['avg_grade'])
        debt, absences, unjustified, missing = (int(row[x]) for x in ('failed_subjects','absences_total','absences_unexcused','assignments_missing'))
        if not math.isfinite(grade) or not 0 <= grade <= 5 or min(debt, absences, unjustified, missing) < 0 or unjustified > absences:
            raise ValueError('Некорректные показатели строки')
        total_grade += grade; total_absences += absences; unexcused += unjustified; failed += debt > 0
        reasons = [label for condition, label in [(grade < 3.5, 'средний балл ниже 3,5'), (debt > 0, 'задолженности'), (unjustified >= 6, 'неуважительные пропуски'), (missing >= 3, 'несданные задания')] if condition]
        if reasons:
            risk.append({'student_id': student, 'reasons': reasons, 'level': 'high' if len(reasons) >= 2 else 'medium'})
    return {'students': len(rows), 'average_grade': round(total_grade / len(rows), 2), 'absences_total': total_absences, 'absences_unexcused': unexcused, 'with_failed_subjects': failed, 'risk': risk}

def process(message):
    method = message.get('method'); request_id = message.get('id')
    if request_id is None: return None
    if method == 'initialize':
        result = {'protocolVersion': message.get('params', {}).get('protocolVersion', '2024-11-05'), 'capabilities': {'tools': {}}, 'serverInfo': {'name': 'stat-collector', 'version': '1.0.0'}}
    elif method == 'ping': result = {}
    elif method == 'tools/list':
        result = {'tools': [{'name': 'analyze_group_stats', 'description': 'Рассчитать показатели по синтетической учебной ведомости data/group_stats.csv', 'inputSchema': {'type': 'object', 'properties': {}, 'additionalProperties': False}}]}
    elif method == 'tools/call':
        try:
            if message.get('params', {}).get('name') != 'analyze_group_stats': raise ValueError('Неизвестный инструмент')
            result = {'content': [{'type': 'text', 'text': json.dumps(analyze(DATA), ensure_ascii=False)}]}
        except (OSError, ValueError, KeyError, TypeError) as exc:
            result = {'isError': True, 'content': [{'type': 'text', 'text': 'Ошибка входных данных: ' + str(exc)}]}
    else:
        return {'jsonrpc': '2.0', 'id': request_id, 'error': {'code': -32601, 'message': 'Method not found'}}
    return {'jsonrpc': '2.0', 'id': request_id, 'result': result}

def main():
    for line in sys.stdin:
        try:
            response = process(json.loads(line))
            if response is not None: print(json.dumps(response, ensure_ascii=False), flush=True)
        except (ValueError, TypeError, AttributeError):
            print(json.dumps({'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Parse error'}}), flush=True)

if __name__ == '__main__': main()
