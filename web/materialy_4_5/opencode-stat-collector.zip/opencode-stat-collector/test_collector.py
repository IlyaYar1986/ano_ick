import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).parent
spec = importlib.util.spec_from_file_location('collector', ROOT / 'mcp' / 'server.py')
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)

class CollectorTest(unittest.TestCase):
    def test_fixture_and_boundary(self):
        report = collector.analyze(ROOT / 'data' / 'group_stats.csv')
        self.assertEqual((report['students'], report['average_grade'], report['absences_total'], report['absences_unexcused'], report['with_failed_subjects']), (12, 3.8, 71, 37, 3))
        risk = {r['student_id']: r for r in report['risk']}
        self.assertEqual(set(risk), {'S003','S004','S006','S009','S010','S012'})
        self.assertEqual(risk['S006']['reasons'], ['несданные задания'])
        self.assertEqual(risk['S009']['level'], 'high')

if __name__ == '__main__': unittest.main()
